import React, { useState } from "react";
import "./LoginForm.css";

import Card from "../Card/Card";
import { database } from "../../utils/database";

import PersonIcon from '@mui/icons-material/Person';
import LockIcon from '@mui/icons-material/Lock';


const LoginForm = ({ setIsLoggedIn }) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessages, setErrorMessages] = useState({});

  const errors = {
    username: "Invalid username",
    password: "Invalid password",
    noUsername: "Please enter your username",
    noPassword: "Please enter your password",
  };

  const handleSubmit = (e) => {
    // Prevent page from reloading
    e.preventDefault();

    if (!username) {
      // Username input is empty
      setErrorMessages({ name: "noUsername", message: errors.noUsername });
      return;
    }

    if (!password) {
      // Password input is empty
      setErrorMessages({ name: "noPassword", message: errors.noPassword });
      return;
    }

    // Search for user credentials
    const currentUser = database.find((user) => user.username === username);

    if (currentUser) {
      if (currentUser.password !== password) {
        // Wrong password
        setErrorMessages({ name: "password", message: errors.password });
      } else {
        // Correct password, log in user
        setErrorMessages({});
        setIsLoggedIn(true);
      }
    } else {
      // Username doens't exist in the database
      setErrorMessages({ name: "username", message: errors.username });
    }
  };

  // Render error messages
  const renderErrorMsg = (name) =>
    name === errorMessages.name && (
      <p className="error_msg">{errorMessages.message}</p>
    );

  return (
    <Card>
      <h1 className="title">User Login</h1>
      
      <form onSubmit={handleSubmit}>
        <div className="inputs_container">
          <div className="input_title">USERNAME</div>
          <div className="input_icon_container">
            <PersonIcon className="icon"/>
            <input
              type="text"
              placeholder="Insert your username here"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>
          {renderErrorMsg("username")}
          {renderErrorMsg("noUsername")}
  
          <div className="input_title">PASSWORD</div>
          <div className="input_icon_container">
            <LockIcon className="icon"/>
            <input
              type="password"
              placeholder="Insert your password here"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          {renderErrorMsg("password")}
          {renderErrorMsg("noPassword")}
        </div>

        <input type="submit" value="Log In" className="login_button" />
        <div className="link_container">
          <a href="" className="small">
            Not a Member?
          </a>
        </div>
        <input type="register" value="Create User Account" className="register_button"/>
      </form>
    </Card>
  );
};

export default LoginForm;
